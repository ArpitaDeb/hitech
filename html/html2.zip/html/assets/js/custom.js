// Windows Loader
$(window).load(function(){
});
$(window).resize(function(){
});
